
```
apt update && apt upgrade -y
```
```
git clone https://github.com/AlwaysBoyszz/Ubotpremboy
```
```
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
```
```
cd Ubotpremboy && screen -S Ubotpremboy
```
```
bash installnode.sh && apt install python3.10-venv
```
```
python3 -m venv Ubotpremboy && source Ubotpremboy/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```
